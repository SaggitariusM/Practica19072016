var app=angular.module('app',['ngRoute','ngResource']);
app.config(function ($routeProvider) {
	$routeProvider.when('/p1', {
		templateUrl: 'pagina1.html'
	})
	.when('/p2', {
		templateUrl: 'pagina2.html',
		controller: 'controlador2'
	})
	.when('/p3', {
		templateUrl: 'pagina3.html',
		controller: 'controlador3'
	})
	.when('/p45', {
		templateUrl: 'pagina4.html',
		controller: 'controlador45'
	})
	.when('/p7', {
		templateUrl: 'pagina7.html',
		controller:'controlador7'
	})
	.when('/p9', {
		templateUrl: 'pagina9.html',
		controller: 'controlador9'
	})
	.otherwise({
		redirectTo: '/p1'
	});
});

app.factory('listaNombres',function () {
	return [{nombres:"Manuel"},{nombres:"Fernanda"},{nombres:"Katherine"}];
});
app.factory('listaDiccionario',function(){
	return [{nombres:"Manuel Mora",telefono:"2139385",carrera:"SISTEMAS"},
		{nombres:"Fernanda Jaramillo",telefono:"2139386",carrera:"ARQUITECTURA"},
		{nombres:"Katherine Mora",telefono:"2139385",carrera:"MEDICINA"}];
});
app.factory('documento',function($resource){
	return $resource("js/documento1.php", {},{'get':{method:'GET',isArray:true}});
}),
app.factory('documentoweb',function($resource){
	return $resource("https://whispering-woodland-9020.herokuapp.com/getAllBooks",{}, {'get':{method:'GET',isArray:false}});
});
app.controller("controlador2",function($scope){
	$scope.nombres="Manuel Mora";
	$scope.lista=["lazzi","rufo","violeta"];
	$scope.diccionario=[{materia:"Programacion Avanzada",creditos:"8"},
	{materia:"Ensamblador",creditos:"8"},
	{materia:"Contabilidad",creditos:"5"}];
});
app.controller("controlador3",function($scope,listaNombres){
	$scope.diccionario=listaNombres;

	$scope.agregarNombre=function(nombreEntrada){
		$scope.diccionario.push({nombres:$scope.nombreEntrada});
		$scope.nombreEntrada="";
	};
	$scope.eliminarLista=function(){
		$scope.diccionario=[];
		//$scope.diccionario="";
	}
});
app.controller("controlador45",function($scope,listaDiccionario,$http){
	$scope.diccionario=listaDiccionario;
	$scope.agregar=function(nombresE,telefonoE,carreraE){
		$scope.diccionario.push({nombres:$scope.nombresE,telefono:$scope.telefonoE,carrera:$scope.carreraE});
		$scope.nombresE="";
		$scope.telefonoE="";
		$scope.carreraE="";
	};
	$scope.ordenar=function(order){
		$scope.ordenado=order;
	};
	$scope.mostraro=true;
	$scope.ocultar_mostrar=function(){
		$scope.mostraro=!$scope.mostraro;
	};
	$http.get("documento1.json").then(function(response){
		$scope.datos=response.data;
	});
});
app.controller('controlador7',function($scope,documento){
	$scope.lista=documento.get();
});
app.controller('controlador9',function($scope,documentoweb){
	$scope.datos=documentoweb.get();
	$scope.ordenar=function(criteriob){
		$scope.orden=criteriob;
	}
	$scope.contar=function(posicion){
		var i=0;
		var j=0;
		for(;i<$scope.datos.books[posicion].salesPerMonth.length;i++){
			j=j+$scope.datos.books[posicion].salesPerMonth[i].amount;
		};
		return j;
	};
});
function ControladorApp($scope){
	$scope.nombre="manuel";
}
app.controller("controlador",ControladorApp);