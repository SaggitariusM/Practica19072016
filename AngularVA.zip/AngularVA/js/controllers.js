angular.module('starter.controllers', [])

.controller('CrtlCom', ['$scope','$http','$state', function($scope,$http,$state){
    
  $scope.buscar = function  () {
      $http.get("http://181.198.51.178:8083/php/get_all_comercial_busqueda.php?nombre="+$scope.nombremedicamento).success(function(data){
          $scope.medicamentos = data.MEDICAMENTO;
      });
       

    }
  
}])

.controller('CrtlGen', ['$scope','$http','$state', function($scope,$http,$state){
    
  $scope.buscar = function  () {
      $http.get("http://181.198.51.178:8083/php/get_all_generico_busqueda.php?nombre="+$scope.nombremedicamento).success(function(data){
          $scope.medicamentos = data.MEDICAMENTO;
      });
       

    }
  
}])

.controller('CrtlRem', ['$scope','$http','$state', function($scope,$http,$state){
    
  $scope.buscar = function  () {
      $http.get("http://181.198.51.178:8083/php/get_all_busqueda_medicamentos_lista.php?nombre="+$scope.nombremedicamento).success(function(data){
          $scope.medicamentos = data.MEDICAMENTO;
      });
       

    }
  
}])

.controller('CtrldetCom', ['$scope', '$http', '$state', function($scope, $http, $state) {
  $http.get('http://181.198.51.178:8083/php/get_all_comercial_busqueda.php?nombre='+$state.params.NOMBRE)
  .success(function(data){
    for (var i = 0; i < data.MEDICAMENTO.length; i++) {
      if (data.MEDICAMENTO[i].CODIGO === $state.params.CODIGO) {
              $scope.data = data.MEDICAMENTO[i];
      }
    }

  });
}])

.controller('CtrldetGen', ['$scope', '$http', '$state', function($scope, $http, $state) {
  $http.get('http://181.198.51.178:8083/php/get_all_generico_busqueda.php?nombre='+$state.params.NOMBRE)
  .success(function(data){
    for (var i = 0; i < data.MEDICAMENTO.length; i++) {
      if (data.MEDICAMENTO[i].CODIGO === $state.params.CODIGO) {
              $scope.data = data.MEDICAMENTO[i];
      }
    }

  });
}])

.controller('CtrldetRem', ['$scope', '$http', '$state', function($scope, $http, $state) {



function initialize() {
        var myLatlng = new google.maps.LatLng(43.07493,-89.381388);

        var mapOptions = {
          center: myLatlng,
          zoom: 12,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("map"),
            mapOptions);
        
        $scope.map = map;
      }

navigator.geolocation.getCurrentPosition(function (pos) {
      console.log('Got pos', pos);
      $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
      var myLatlng = new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude);
      var marker = new google.maps.Marker({
          position: myLatlng,
          map: $scope.map,
          icon: 'https://dl.dropboxusercontent.com/u/20056281/Iconos/male-2.png',
          
        });

      
    }, function (error) {
      alert('Unable to get location: ' + error.message);
    });

$http.get('http://181.198.51.178:8083/php/get_all_busqueda_medicamentos_farmacia.php?nombre='+$state.params.NOMBRE)
  .success(function(data){
   
   for (var i = 0; i < data.FARMACIA.length; i++) {
      
      var posfarmacia = new google.maps.LatLng(data.FARMACIA[i].LATITUD, data.FARMACIA[i].LONGITUD);

      var infowindow = new google.maps.InfoWindow({
    content: 'contentString'
  });


      var marker = new google.maps.Marker({
          position: posfarmacia,
          map: $scope.map,
          icon: 'https://dl.dropboxusercontent.com/u/20056281/Iconos/male-2.png'

          
        });

      marker.addListener('click', function() {
    infowindow.open(map, marker);
  });

      
    }
              
     

  });


      if (document.readyState === "complete") {
        initialize()
      }else{
        google.maps.event.addDomListener(window, 'load', initialize)
      }
      
}])


