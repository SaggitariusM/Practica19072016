var app=angular.module("app",[]);

function listado($scope,$http){
	$scope.diccionario=[{nombres:"Manuel Mora",telefono:"2139385",carrera:"SISTEMAS"},
		{nombres:"Fernanda Jaramillo",telefono:"2139386",carrera:"ARQUITECTURA"},
		{nombres:"Katherine Mora",telefono:"2139385",carrera:"MEDICINA"}];
	$scope.agregar=function(nombresE,telefonoE,carreraE){
		$scope.diccionario.push({nombres:$scope.nombresE,telefono:$scope.telefonoE,carrera:$scope.carreraE});
		$scope.nombresE="";
		$scope.telefonoE="";
		$scope.carreraE="";
	};
	$scope.ordenar=function(order){
		$scope.ordenado=order;
	};
	$scope.mostraro=true;
	$scope.ocultar_mostrar=function(){
		$scope.mostraro=!$scope.mostraro;
	};
}

app.controller("controlador",listado);