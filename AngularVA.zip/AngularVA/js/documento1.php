[
	{"datos_persona":{"nombres":"Manuel",
					"apellidos":"Mora"
					},
		"estudios":{"universidad":"UNL","carrera":"SISTEMAS"}
	},
	{"datos_persona":{"nombres":"Fernanda",
					"apellidos":"Jaramillo"
					},
		"estudios":{"universidad":"UTPL","carrera":"ARQUITECTURA"}
	},
	{"datos_persona":{"nombres":"Katherine",
					"apellidos":"Mora",
					"cedula":"1105109496"
					},
		"estudios":{"universidad":"UTPL","carrera":"COMUNICACIÓN SOCIAL"}
	}
]