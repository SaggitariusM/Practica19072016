var app=angular.module('app', ['ngResource']);

function LeerJsonClima($scope,documento){
	$scope.datos=documento.get();
	$scope.ordenar=function(criteriob){
		$scope.orden=criteriob;
	}
	$scope.contar=function(posicion){
		var i=0;
		var j=0;
		for(;i<$scope.datos.books[posicion].salesPerMonth.length;i++){
			j=j+$scope.datos.books[posicion].salesPerMonth[i].amount;
		};
		return j;
	};
}
app.factory('documento',function($resource){
	return $resource("https://whispering-woodland-9020.herokuapp.com/getAllBooks",{}, {'get':{method:'GET',isArray:false}});
});
app.controller('controlador',LeerJsonClima);