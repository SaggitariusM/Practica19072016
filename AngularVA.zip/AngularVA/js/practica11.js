//se define los paquetes o módulos a utilizar de angularjs
var app=angular.module('app', ['ngResource']);
//se define el controlador
app.controller('controlador',function($scope,datos){
	$scope.mensaje="datos";
	$scope.lista=datos.get();
	$scope.ordenar=function(valor){
		$scope.orden=valor;
	};
});
//definir el factory que retorne datos de un webservice
app.factory('datos',function($resource){
	return $resource('http://127.0.0.1:8000/ws/cliente/', {}, {'get':{method:'GET',isArray:true}});
});