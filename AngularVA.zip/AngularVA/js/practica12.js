var app=angular.module('app', ['ngResource']);

app.controller('controlador',function($scope,datoscl,datoscur){
	$scope.mensaje="hola mundo";
	$scope.datoscliente=datoscl.get();
	$scope.datoscurso=datoscur.get();
	$scope.validar=function(cedulaI){
		alert(cedulaI);

	}
});
app.factory('datoscl',function($resource){
	return $resource("http://127.0.0.1:8000/ws/cliente/", {}, {'get':{method:'GET',isArray:true}});
});
app.factory('datoscur',function($resource){
	return $resource("http://127.0.0.1:8000/ws/curso/", {}, {'get':{method:'GET',isArray:true}});
});