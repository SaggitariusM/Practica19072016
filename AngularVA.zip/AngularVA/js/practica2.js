var app=angular.module('primero', [])

app.controller('controlador2', function ($scope) {
	$scope.nombres="Manuel Mora";
	$scope.lista=["lazzi","rufo","violeta"];
	$scope.diccionario=[{materia:"Programacion Avanzada",creditos:"8"},
	{materia:"Ensamblador",creditos:"8"},
	{materia:"Contabilidad",creditos:"5"}];
});