var app=angular.module('app', ['ngResource']);

function LeerJson($scope,listado,listado2){
	$scope.mensaje="hola mundo";
	$scope.lista=listado.get();
	$scope.lista2=listado2.get();
}
app.factory("listado",function($resource){
	return $resource("js/documento1.php",{}, {'get':{method:'GET',isArray:true}});
});
app.factory("listado2",function($resource){
	return $resource("js/package.json",{}, {'get':{method:'GET',isArray:false}});
});
app.controller("controlador",LeerJson);