var app=angular.module("app",[]);

function entrada($scope){
	$scope.diccionario=[
	{nombres:"Manuel"},
	{nombres:"Fernanda"},
	{nombres:"Carlos"}];

	$scope.agregarNombre=function(nombreEntrada){
		$scope.diccionario.push({nombres:$scope.nombreEntrada});
		$scope.nombreEntrada="";
	};
	$scope.eliminarLista=function(){
		$scope.diccionario=[];
		//$scope.diccionario="";
	}
}
app.controller("controlador", entrada);