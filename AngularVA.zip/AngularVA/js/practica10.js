var app=angular.module('app', ['ngResource']);

app.controller('controlador',function($scope,datos,$http){
	$scope.nombres="manuel";
	$scope.documento=datos.get();
	//CON HTTP
	$http.get('js/medicamentos.php').then(function(response){
		$scope.documento2=response.data.MEDICAMENTO;
	});
});
app.factory('datos',function($resource){
	return $resource('js/medicamentos.php',{},{'get':{method:'GET',isArray:false}});
	//return $resource('http://181.198.51.178:8083/php/get_all_comercial.php',{},{'get':{method:'GET',isArray:false}});
});