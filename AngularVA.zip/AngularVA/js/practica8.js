var app=angular.module('app', []);

function LeerJson($scope,$http){
	$http.get('js/documento1.php').success(function(response){
		$scope.lista=response;
	});
}
app.controller("controlador",LeerJson);