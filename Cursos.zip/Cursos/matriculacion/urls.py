from django.conf.urls import url
from django.contrib import admin
from .import views
urlpatterns = [
	url(r'^$','matriculacion.views.listar'),
    url(r'^CrearCliente/$', "matriculacion.views.CrearCliente",name="CrearCliente"),
    url(r'^matricular/$', "matriculacion.views.matricularse",name="matricular"),
    url(r'^CrearCurso/$', "matriculacion.views.CrearCurso",name="CrearCurso"),
]