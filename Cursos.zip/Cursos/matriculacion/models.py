from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Cliente(models.Model):
	nombres=models.CharField(max_length=30)
	apellidos=models.CharField(max_length=30)
	cedula=models.CharField(max_length=10, unique=True)
	telefono=models.CharField(max_length=20, blank=True)

	def __str_(self):
		return self.cedula
class Curso(models.Model):
	nombre=models.CharField(max_length=30)
	cupo=models.IntegerField()
	numeroCurso=models.IntegerField(unique=True)

	def _str_(self):
		return self.numeroCurso

class CursoMatricula(models.Model):
	idCliente=models.ForeignKey(Cliente,on_delete=models.CASCADE,default="")
	idCurso=models.ForeignKey(Curso,on_delete=models.CASCADE,default="")
	fecha_inscripcion=models.DateTimeField(auto_now=True, auto_now_add=False)
	numeroMatricula=models.IntegerField()

	def _str_(self):
		return self.numeroMatricula