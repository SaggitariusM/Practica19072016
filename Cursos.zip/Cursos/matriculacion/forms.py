from django import forms
from .models import Cliente
from .models import Curso
class FormularioCliente(forms.ModelForm):
	class Meta:
		model=Cliente
		fields=["nombres","apellidos","cedula","telefono"]

class FormularioCurso(forms.ModelForm):
	class Meta:
		model=Curso
		fields=["nombre","cupo"]