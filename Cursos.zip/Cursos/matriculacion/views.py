from django.shortcuts import render, redirect
from .forms import FormularioCliente
from .forms import FormularioCurso
from .models import Cliente
from .models import Curso
# Create your views here.
def listar(request):
	objcl=Cliente.objects.all()
	context={
		"lista_clientes":objcl,
	}
	return render(request,"inicio.html",context)
def CrearCliente(request):
	if(request.method=="POST"):
		nom=request.POST["nombres"]
		apell=request.POST["apellidos"]
		ced=request.POST["cedula"]
		tel=request.POST["telefono"]

		objcl=Cliente.objects.create(nombres=nom,apellidos=apell,cedula=ced,telefono=tel)
		objcl.save()
		return redirect("/cursos")
	fc=FormularioCliente(request.POST or None)
	context={
		"f":fc,
	}
	return render(request,"crear_cliente.html",context)
def CrearCurso(request):
	if(request.method=="POST"):
		nom=request.POST["nombre"]
		limite=request.POST["cupo"]
		numc=len(Curso.objects.all())+1
		objcur=Curso.objects.create(nombre=nom,cupo=limite,numeroCurso=numc)
		return redirect("/cursos")

	fcur=FormularioCurso(request.POST or None)
	context={
		"f":fcur,
	}
	return render(request,"crear_curso.html",context)
def matricularse(request):
	objcur=Curso.objects.all()
	ced=request.GET["cedula"]
	context={
		"cedula":ced,
		"lista_cursos":objcur,
	}
	return render(request,"matricular.html",context)