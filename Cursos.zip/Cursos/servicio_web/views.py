from django.shortcuts import render
from matriculacion.models import Cliente
from rest_framework import viewsets
from .serializable import ClienteSerializable
from matriculacion.models import Curso
from .serializable import CursoSerializable
# Create your views here.
class ClienteViewSet(viewsets.ModelViewSet):
	#llamar al objeto serializable
	serializer_class=ClienteSerializable
	#Access-Control-Allow-Origin = "Access-Control-Allow-Origin" ":" origin-list-or-null
	#se define la consulta de datos que se enviaran al webservice
	queryset=Cliente.objects.all().order_by("nombres")

class CursoViewSet(viewsets.ModelViewSet):
	#llamar al objeto serializable
	serializer_class=CursoSerializable
	#Access-Control-Allow-Origin = "Access-Control-Allow-Origin" ":" origin-list-or-null
	#se define la consulta de datos que se enviaran al webservice
	queryset=Curso.objects.all().order_by("nombre")