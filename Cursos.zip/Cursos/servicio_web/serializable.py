from matriculacion.models import Cliente
from rest_framework import serializers
from matriculacion.models import Curso
class ClienteSerializable(serializers.ModelSerializer):
	class Meta:
		model=Cliente
		fields=['cedula','nombres','apellidos','telefono']
class CursoSerializable(serializers.ModelSerializer):
	class Meta:
		model=Curso
		fields=['numeroCurso','nombre','cupo']